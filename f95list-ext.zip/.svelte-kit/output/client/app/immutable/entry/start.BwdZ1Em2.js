import{s as t}from"../chunks/entry.JS_xsFPS.js";export{t as start};
