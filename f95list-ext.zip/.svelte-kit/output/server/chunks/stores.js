import { w as writable } from "./index.js";
import { w as withGet } from "./button.js";
function toWritableStores(properties) {
  const result = {};
  Object.keys(properties).forEach((key) => {
    const propertyKey = key;
    const value = properties[propertyKey];
    result[propertyKey] = withGet(writable(value));
  });
  return result;
}
function createBitAttrs(bit, parts) {
  const attrs = {};
  parts.forEach((part) => {
    attrs[part] = {
      [`data-${bit}-${part}`]: ""
    };
  });
  return (part) => attrs[part];
}
function removeUndefined(obj) {
  const result = {};
  for (const key in obj) {
    const value = obj[key];
    if (value !== void 0) {
      result[key] = value;
    }
  }
  return result;
}
function getOptionUpdater(options) {
  return function(key, value) {
    if (value === void 0)
      return;
    const store = options[key];
    if (store) {
      store.set(value);
    }
  };
}
const tags = [
  "2d-game",
  "2dcg",
  "3d-game",
  "3dcg",
  "adventure",
  "ahegao",
  "ai-cg",
  "anal-sex",
  "animated",
  "bdsm",
  "bestiality",
  "big-ass",
  "big-tits",
  "blackmail",
  "bukkake",
  "censored",
  "character-creation",
  "cheating",
  "combat",
  "corruption",
  "cosplay",
  "creampie",
  "dating-sim",
  "dilf",
  "drugs",
  "dystopian-setting",
  "exhibitionism",
  "fantasy",
  "female-protagonist",
  "femaledomination",
  "footjob",
  "furry",
  "futa-trans",
  "futa-trans-protagonist",
  "gay",
  "graphic-violence",
  "groping",
  "group-sex",
  "handjob",
  "harem",
  "horror",
  "humiliation",
  "humor",
  "incest",
  "internal-view",
  "interracial",
  "japanese-game",
  "kinetic-novel",
  "lactation",
  "lesbian",
  "loli",
  "male-protagonist",
  "maledomination",
  "management",
  "masturbation",
  "milf",
  "mind-control",
  "mobile-game",
  "monster",
  "monster-girl",
  "multiple-endings",
  "multiple-penetration",
  "multiple-protagonist",
  "necrophilia",
  "no-sexual-content",
  "ntr",
  "oral-sex",
  "paranormal",
  "parody",
  "platformer",
  "point-click",
  "possession",
  "pov",
  "pregnancy",
  "prostitution",
  "puzzle",
  "rape",
  "real-porn",
  "religion",
  "romance",
  "rpg",
  "sandbox",
  "scat",
  "school-setting",
  "sci-fi",
  "sex-toys",
  "sexual-harassment",
  "shooter",
  "shota",
  "side-scroller",
  "simulator",
  "sissification",
  "slave",
  "sleep-sex",
  "spanking",
  "strategy",
  "stripping",
  "superpowers",
  "swinging",
  "teasing",
  "tentacles",
  "text-based",
  "titfuck",
  "trainer",
  "transformation",
  "trap",
  "turn-based-combat",
  "twins",
  "urination",
  "vaginal-sex",
  "virgin",
  "virtual-reality",
  "voiced",
  "vore",
  "voyeurism"
];
const games = writable([]);
const filteredGames = writable([]);
const defaultFilters = () => [
  {
    title: "domain",
    open: false,
    values: [
      { value: "F95z", checked: false },
      { value: "LewdCorner", checked: false },
      { value: "Autre", checked: false }
    ]
  },
  {
    title: "status",
    open: false,
    values: [
      { value: "EN COURS", checked: false },
      { value: "ABANDONNÉ", checked: false },
      { value: "TERMINÉ", checked: false }
    ]
  },
  {
    title: "type",
    open: false,
    values: [
      { value: "RenPy", checked: false },
      { value: "RPGM", checked: false },
      { value: "Unreal", checked: false },
      { value: "HTLM", checked: false },
      { value: "Flash", checked: false },
      { value: "QSP", checked: false },
      { value: "RenPy/RPGM", checked: false },
      { value: "RenPy/Unity", checked: false },
      { value: "Autre", checked: false }
    ]
  },
  {
    title: "tags",
    open: false,
    values: tags.map((tag) => ({ value: tag, checked: false }))
  }
];
const filterFn = () => {
  const { subscribe, set, update } = writable(defaultFilters());
  return {
    subscribe,
    set,
    update,
    reset: () => set(defaultFilters())
  };
};
const filter = filterFn();
const search = writable("");
const updates = writable([]);
const settingsData = localStorage.getItem("settings");
const settings = writable(
  settingsData ? JSON.parse(settingsData) : { tagsHide: true, intergrateFeature: false }
);
export {
  getOptionUpdater as a,
  filter as b,
  createBitAttrs as c,
  settings as d,
  filteredGames as f,
  games as g,
  removeUndefined as r,
  search as s,
  toWritableStores as t,
  updates as u
};
