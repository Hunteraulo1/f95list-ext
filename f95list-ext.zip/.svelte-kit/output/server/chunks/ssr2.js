function onMount() {
}
function afterUpdate() {
}
export {
  afterUpdate as a,
  onMount as o
};
