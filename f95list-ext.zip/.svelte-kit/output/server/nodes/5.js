

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/updates/_page.svelte.js')).default;
export const imports = ["app/immutable/nodes/5.B1_hah6r.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js","app/immutable/chunks/button.CrjbcflE.js","app/immutable/chunks/index.B_IkcMCN.js","app/immutable/chunks/GameBox.BXyyU7t3.js","app/immutable/chunks/card.Dy0gdrts.js","app/immutable/chunks/schemas.Bbb6MsAQ.js","app/immutable/chunks/events.BOgPMPSf.js","app/immutable/chunks/scroll-area.CoBcvyZY.js","app/immutable/chunks/stores.piCmtpBv.js"];
export const stylesheets = ["app/immutable/assets/GameBox.BMmD0yMK.css"];
export const fonts = [];
