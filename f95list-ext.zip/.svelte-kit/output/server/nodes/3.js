

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/_page.svelte.js')).default;
export const imports = ["app/immutable/nodes/3.oE2moBhM.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js","app/immutable/chunks/button.CrjbcflE.js","app/immutable/chunks/index.B_IkcMCN.js","app/immutable/chunks/entry.JS_xsFPS.js","app/immutable/chunks/stores.piCmtpBv.js","app/immutable/chunks/events.BOgPMPSf.js","app/immutable/chunks/mode.Dmd0MyyM.js"];
export const stylesheets = [];
export const fonts = [];
