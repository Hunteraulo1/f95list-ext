import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/+layout.ts";
export const imports = ["app/immutable/nodes/0.CI6yxZC3.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js","app/immutable/chunks/button.CrjbcflE.js","app/immutable/chunks/index.B_IkcMCN.js","app/immutable/chunks/entry.JS_xsFPS.js","app/immutable/chunks/scroll-area.CoBcvyZY.js","app/immutable/chunks/stores.piCmtpBv.js","app/immutable/chunks/schemas.Bbb6MsAQ.js","app/immutable/chunks/mode.Dmd0MyyM.js"];
export const stylesheets = ["app/immutable/assets/0.Dp6Ph8-8.css"];
export const fonts = [];
