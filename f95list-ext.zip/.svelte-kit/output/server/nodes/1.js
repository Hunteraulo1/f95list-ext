

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["app/immutable/nodes/1._WFuraDu.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js","app/immutable/chunks/entry.JS_xsFPS.js","app/immutable/chunks/index.B_IkcMCN.js"];
export const stylesheets = [];
export const fonts = [];
