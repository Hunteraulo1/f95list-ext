

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/traductors/_page.svelte.js')).default;
export const imports = ["app/immutable/nodes/4.BlfXn67F.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js","app/immutable/chunks/button.CrjbcflE.js","app/immutable/chunks/index.B_IkcMCN.js","app/immutable/chunks/card.Dy0gdrts.js","app/immutable/chunks/schemas.Bbb6MsAQ.js"];
export const stylesheets = [];
export const fonts = [];
