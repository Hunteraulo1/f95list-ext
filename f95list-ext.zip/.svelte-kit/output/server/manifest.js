export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "app",
	appPath: "app",
	assets: new Set(["background.js","content.js","favicon.png","manifest_chrome.json","manifest_firefox.json"]),
	mimeTypes: {".js":"text/javascript",".png":"image/png",".json":"application/json"},
	_: {
		client: {"start":"app/immutable/entry/start.BwdZ1Em2.js","app":"app/immutable/entry/app.BBF9oj85.js","imports":["app/immutable/entry/start.BwdZ1Em2.js","app/immutable/chunks/entry.JS_xsFPS.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.B_IkcMCN.js","app/immutable/entry/app.BBF9oj85.js","app/immutable/chunks/scheduler.--Ay5dQs.js","app/immutable/chunks/index.DVkY2XsR.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js'))
		],
		routes: [
			
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
