import { c as create_ssr_component, d as subscribe, e as each, v as validate_component, a as escape } from "../../../chunks/ssr.js";
import { G as GameBox } from "../../../chunks/GameBox.js";
import { B as Button } from "../../../chunks/button.js";
import { u as updates } from "../../../chunks/stores.js";
import { R as Reload } from "../../../chunks/card.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $updates, $$unsubscribe_updates;
  $$unsubscribe_updates = subscribe(updates, (value) => $updates = value);
  $$unsubscribe_updates();
  return `${$updates ? `<div class="flex flex-col gap-4 max-h-full p-2 relative">${each($updates, (update, index) => {
    return `<div class="flex flex-col gap-2">${index === 0 || $updates[index - 1].date.getTime() !== update.date.getTime() ? `<h2 class="text-center font-bold leading-none">${escape(new Date(update.date).toLocaleDateString("fr-FR", { timeZone: "Europe/Paris" }))} </h2>` : ``} <h3 class="text-[.7rem] text-center text-secondary-foreground/50 leading-none">${escape(update.type)}</h3> ${each(update.games, (game) => {
      return `${validate_component(GameBox, "GameBox").$$render($$result, { game }, {}, {})}`;
    })} </div>`;
  })}</div>` : `<div class="flex justify-center items-center h-full">${validate_component(Button, "Button").$$render($$result, {}, {}, {
    default: () => {
      return `${validate_component(Reload, "Reload").$$render($$result, { class: "mr-2 h-4 w-4 animate-spin" }, {}, {})}
      Veuillez patienter`;
    }
  })}</div>`}`;
});
export {
  Page as default
};
