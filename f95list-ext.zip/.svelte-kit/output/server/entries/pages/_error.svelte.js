import { c as create_ssr_component } from "../../chunks/ssr.js";
import { g as goto } from "../../chunks/client.js";
const Error = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  goto();
  return ``;
});
export {
  Error as default
};
