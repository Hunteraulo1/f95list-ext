import { c as create_ssr_component, n as is_promise, p as noop, e as each, v as validate_component, a as escape, b as add_attribute } from "../../../chunks/ssr.js";
import { B as Button } from "../../../chunks/button.js";
import { C as Card, a as Card_content, R as Reload } from "../../../chunks/card.js";
import "clsx";
import "../../../chunks/schemas.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let queryResult = Promise.resolve([]);
  return `${function(__value) {
    if (is_promise(__value)) {
      __value.then(null, noop);
      return ``;
    }
    return function(traductors) {
      return ` ${traductors.length > 0 ? `<div class="flex flex-col gap-4 max-h-full p-2 relative">${each(traductors, ({ name, pages, tradCount, readCount }) => {
        return `${validate_component(Card, "Card.Root").$$render($$result, { class: "relative" }, {}, {
          default: () => {
            return `${validate_component(Card_content, "Card.CardContent").$$render($$result, { class: "p-2 min-h-20" }, {}, {
              default: () => {
                return `<p class="font-bold text-center">${escape(name)}</p> <div class="flex text-sm items-center justify-center"><p class="font-bold text-secondary-foreground/50" data-svelte-h="svelte-cai6kn">Liens:</p> ${pages.length ? each(pages, ({ title, link }) => {
                  return `<a${add_attribute("href", link, 0)} target="_blank">${validate_component(Button, "Button").$$render($$result, { variant: "link", class: "px-1" }, {}, {
                    default: () => {
                      return `${escape(title)} `;
                    }
                  })} </a>`;
                }) : `<p class="px-1 py-2" data-svelte-h="svelte-1je2e5z">Aucun lien</p>`}</div> <div class="flex justify-around w-full"><p class="text-sm font-bold text-secondary-foreground/50">Traduction: <span class="text-secondary-foreground">${escape(tradCount)}</span></p> <p class="text-sm font-bold text-secondary-foreground/50">Relecture: <span class="text-secondary-foreground">${escape(readCount)}</span> </p></div> `;
              }
            })} `;
          }
        })}`;
      })}</div>` : `<div class="flex justify-center items-center min-h-full">${validate_component(Button, "Button").$$render($$result, {}, {}, {
        default: () => {
          return `${validate_component(Reload, "Reload").$$render($$result, { class: "mr-2 h-4 w-4 animate-spin" }, {}, {})}
        Veuillez patienter`;
        }
      })}</div>`} `;
    }(__value);
  }(queryResult)}`;
});
export {
  Page as default
};
