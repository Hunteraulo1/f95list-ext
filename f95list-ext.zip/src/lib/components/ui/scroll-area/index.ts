import Scrollbar from './scroll-area-scrollbar.svelte'
import Root from './scroll-area.svelte'

export {
  Root,
  //,
  Root as ScrollArea,
  Scrollbar as ScrollAreaScrollbar,
  Scrollbar,
}
