<script lang="ts">
import { cn } from '$lib/utils.js'
import { Label as LabelPrimitive } from 'bits-ui'

type $$Props = LabelPrimitive.Props

let className: $$Props['class'] = undefined
export { className as class }
</script>

<LabelPrimitive.Root
	class={cn(
		"text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
		className
	)}
	{...$$restProps}
>
	<slot />
</LabelPrimitive.Root>
