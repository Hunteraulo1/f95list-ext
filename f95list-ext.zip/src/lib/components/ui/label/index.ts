import Root from './label.svelte'

export {
  Root,
  //
  Root as Label,
}
