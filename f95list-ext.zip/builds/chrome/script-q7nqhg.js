
				{
					__sveltekit_1gefdzn = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("./app/immutable/entry/start.C8-lkSNF.js"),
						import("./app/immutable/entry/app.BQhDg64O.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			