import{s as t}from"../chunks/entry.BoAXNhYI.js";export{t as start};
