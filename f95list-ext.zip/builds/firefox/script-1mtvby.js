
				{
					__sveltekit_1xlzwhg = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("./app/immutable/entry/start.BwdZ1Em2.js"),
						import("./app/immutable/entry/app.BBF9oj85.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			